import React from 'react';
function signup() {
    return (
        <h1>signup</h1>
    );
}

export default signup;