import React from 'react';
import CreateTicket from './CreateTicket';
import Hero from './Hero';

function SupportPage() {
    return (
        <>
        <CreateTicket/>
        <Hero/>
        </>
    );
}

export default SupportPage;